Action()
{

	web_service_call( "StepName=GetCultureInfo_101",
		"SOAPMethod=Converter|ConverterSoap|GetCultureInfo",
		"ResponseParam=response",
		"Service=Converter",
		"ExpectedResponse=SoapResult",
		"Snapshot=t1570637488.inf",
		BEGIN_ARGUMENTS,
		"Currency=USD",
		END_ARGUMENTS,
		BEGIN_RESULT,
		"GetCultureInfoResult=Param_GetCultureInfoResult",
		END_RESULT,
		LAST);

		return 0;
}
