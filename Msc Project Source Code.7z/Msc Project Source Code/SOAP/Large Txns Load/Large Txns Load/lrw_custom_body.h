/*********************************************************
// This file contains the body sections 
// recorded for web_custom_request function.
**********************************************************/

