	Action()
{

web_service_call( "StepName=GetCurrencies_101",
		"SOAPMethod=Converter|ConverterSoap|GetCurrencies",
		"ResponseParam=response",
		"Service=Converter",
		"ExpectedResponse=SoapResult",
		"Snapshot=t1570638307.inf",
		BEGIN_ARGUMENTS,
		END_ARGUMENTS,
		BEGIN_RESULT,
		END_RESULT,
		LAST);


	return 0;
}
